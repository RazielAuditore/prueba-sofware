/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prueba.software.de.escritorio;

import java.util.ArrayList;
import java.util.List;
import prueba.software.de.escritorio.DTO.clubdeportivo;
import prueba.software.de.escritorio.DTO.usuario;
import sun.security.util.Password;


/**
 *
 * @author sebas
 */
public class PruebaSoftwareDeEscritorio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        
        
        //crear 3 usuarios 
        clubdeportivo uno =new clubdeportivo();
        uno.setRol(12345);
        uno.setFundador("jorge");
        uno.setAno_fundacion(2022/04/04);
        uno.setPais_origen("bolivia");
        uno.setCodigo("get");
        uno.setNombre("ARSENAL DE COQUIMBO");
        uno.setLema("cañones a los puertos");
        uno.setSuscripcion(10500);
        uno.setColores("amarillo, rojo");
        
        clubdeportivo dos=new clubdeportivo();
        dos.setRol(12344);
        dos.setFundador("el dios mossa");
        dos.setAno_fundacion(1998);
        dos.setPais_origen("peru");
        dos.setCodigo("11234");
        dos.setNombre("los condores unidos");
        dos.setLema("desde lo alto al sol");
        dos.setSuscripcion(13200);
        dos.setColores("amarillo,naranjo");
        
        clubdeportivo tres=new clubdeportivo();
        tres.setRol(123345);
        tres.setFundador("dios");
        tres.setAno_fundacion(1998);
        tres.setPais_origen("chile");
        tres.setCodigo("12345");
        tres.setNombre("manquehue city");
        tres.setLema("vivir y fuerza");
        tres.setSuscripcion(15100);
        tres.setColores("celeste,blanco");
        
        System.out.println(tres.getCodigo());
    
        
        
        
        
        
        //metodo concatenacion de colores
        String mas_colores=uno.getColores()+ dos.getColores()+tres.getColores();
       
         //lista
        List<String> lista_equipos=new ArrayList<>();
        lista_equipos.add(tres.getCodigo());
        lista_equipos.add(dos.getCodigo());
        lista_equipos.add(uno.getCodigo());
                
        List<Integer> lista_suscripcion=new ArrayList<>();
        lista_suscripcion.add(tres.getSuscripcion());
        lista_suscripcion.add(dos.getSuscripcion());
        lista_suscripcion.add(uno.getSuscripcion());
        
           
    
       for(String n:lista_equipos)
            System.out.println("nombre:"+n);
            
        }
        
        //
        
 
    
                
        usuario uno=new usuario();{
        uno.setID(123245);
        uno.setNombre_completo("jorge rico");
        uno.setEmail("kapo@gmail.com");
        uno.setRut(17518203);
        uno.setDV(9);
        uno.setFecha("20/10/2022");
        uno.setTelefono(37670016);
        uno.setNombre_usuario("abcd");
        uno.setContraseña("altf5");
        
        usuario dos=new usuario();
        dos.setID(1000);
        dos.setNombre_completo("ricj jonas");
        dos.setEmail("david.cogiolle@gmail.com");
        dos.setRut(18123456);
        dos.setDV(9);
        dos.setFecha("12/10/2022");
        dos.setTelefono(71425220);
        dos.setNombre_usuario("jorgito");
        dos.setContraseña("altf4");
        
        
        usuario tres=new usuario();
        tres.setID(1234567);
        tres.setNombre_completo("jorge");
        tres.setEmail("donwea@hotmail.com");
        tres.setRut(15122098);
        tres.setDV(7);
        tres.setFecha("dd/mm/aaaa");
        tres.setTelefono(1234545);
        tres.setNombre_usuario("jorge putt");
        tres.setContraseña("12345");
        
      
     
        
        
        
        
        
        
        
              
        
 

              
              
        
       

        
        
    }
     
    
             
    
    
}
