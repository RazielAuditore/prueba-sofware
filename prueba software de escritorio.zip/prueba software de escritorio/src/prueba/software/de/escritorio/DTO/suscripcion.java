/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.software.de.escritorio.DTO;

/**
 *
 * @author sebas
 */
public class suscripcion  {
    private Integer fechapago;
    private Integer valorsuscripcion;
    private Integer equipossuscritos;
    private Integer abonodepago;
    private Integer correlativo;
    
    public suscripcion(){
        this.abonodepago=0;
        this.correlativo=0;
        this.equipossuscritos=0;
        this.valorsuscripcion=0;
        this.fechapago=0;
        
    }
    public suscripcion(Integer fechapago,Integer valorsuscripcion,Integer equipossuscritos,Integer abonodepago,Integer correlativo){
        this.abonodepago=abonodepago;
        this.correlativo=correlativo;
        this.equipossuscritos=equipossuscritos;
        this.fechapago=fechapago;
        this.valorsuscripcion=valorsuscripcion;
        
        
        
    }

    public Integer getFechapago() {
        return fechapago;
    }

    public Integer getValorsuscripcion() {
        return valorsuscripcion;
    }

    public Integer getEquipossuscritos() {
        return equipossuscritos;
    }

    public Integer getAbonodepago() {
        return abonodepago;
    }

    public Integer getCorrelativo() {
        return correlativo;
    }

    public void setFechapago(Integer fechapago) {
        this.fechapago = fechapago;
    }

    public void setValorsuscripcion(Integer valorsuscripcion) {
        this.valorsuscripcion = valorsuscripcion;
    }

    public void setEquipossuscritos(Integer equipossuscritos) {
        this.equipossuscritos = equipossuscritos;
    }

    public void setAbonodepago(Integer abonodepago) {
        this.abonodepago = abonodepago;
    }

    public void setCorrelativo(Integer correlativo) {
        this.correlativo = correlativo;
    }
    
    
}
