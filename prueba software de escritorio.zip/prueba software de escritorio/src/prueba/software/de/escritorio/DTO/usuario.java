/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.software.de.escritorio.DTO;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.util.ArrayList;

/**
 *
 * @author sebas
 */
public class usuario {
    private Integer ID;
    private String nombre_completo;
    private String email;
    private Integer rut;
    private Integer DV;
    private String fecha ;
    private Integer telefono;
    private String nombre_usuario;
    private String contraseña;
    
    public usuario(){
        this.ID=0;
        this.nombre_completo="";
        this.email="";
        this.rut=0;
        this.DV=0;
        this.fecha="";
        this.telefono=0;
        this.nombre_usuario="";
        this.contraseña="";
        
    }
    public usuario(Integer ID,String nombre_completo,String email,Integer rut, Integer DV,String fecha ,Integer telefono,String nombre_de_usuario,String contraseña){
        this.ID=ID;
        this.nombre_completo=nombre_completo;
        this.email=email;
        this.rut=rut;
        this.DV=DV;
        this.fecha=fecha;
        this.telefono=telefono;
        this.nombre_usuario=nombre_usuario;
        
    }

    public Integer getID() {
        return ID;
    }

    public String getNombre_completo() {
        return nombre_completo.substring(0,2);
    }

    public String getEmail() {
        return email;
    }

    public Integer getRut() {
        return rut;
    }

    public Integer getDV() {
        return DV;
    }

    public String getFecha() {
        return fecha;
    }

    public Integer getTelefono() {
        return telefono;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public void setNombre_completo(String nombre_completo) {
        this.nombre_completo = nombre_completo;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRut(Integer rut) {
        this.rut = rut;
    }

    public void setDV(Integer DV) {
        this.DV = DV;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setTelefono(Integer telefono) {
        this.telefono = telefono;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    


}
    
    
    
        

   

    

        
    
    
           


   
