/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.software.de.escritorio.DTO;

/**
 *
 * @author sebas
 */
public class clubdeportivo {
    private Integer rol;
    private String fundador;
    private Integer anofundacion;
    private String pais_origen;
    private String codigo;
    private String nombre;
    private String lema;
    private Integer suscripcion;
    private String colores;
    
    public clubdeportivo(){
        this.rol=0;
        this.fundador="";
        this.anofundacion=0;
        this.pais_origen="";
        this.codigo="";
        this.nombre="";
        this.lema="";
        this.suscripcion=0;
        this.colores="";
        }
    
    public clubdeportivo(String codigo,String nombre,String lema , Integer suscripcion,String colores,Integer rol,String fundador,Integer ano_fun,String pais_origen){
        this.codigo=codigo;
        this.nombre=nombre;
        this.lema=lema;
        this.suscripcion=suscripcion;
        this.colores=colores;
        this.rol=rol;
        this.fundador=fundador;
        this.anofundacion=anofundacion;
        this.pais_origen=pais_origen;
        
        
        
    }

    public Integer getRol() {
        return rol;
    }

    public String getFundador() {
        return fundador;
    }

    public Integer getAno_fundacion() {
        return anofundacion;
    }

    public String getPais_origen() {
        return pais_origen;
    }

    public String getCodigo() {
        return nombre.substring(0,2)+"H"+"11";
    }

    public String getNombre() {
        return nombre;
    }

    public String getLema() {
        return lema;
    }

    public Integer getSuscripcion() {
        return suscripcion;
    }

    public String getColores() {
        return colores;
    }

    public void setRol(Integer rol) {
        this.rol = rol;
    }

    public void setFundador(String fundador) {
        this.fundador = fundador;
    }

    public void setAno_fundacion(Integer ano_fundacion) {
        this.anofundacion = ano_fundacion;
    }

    public void setPais_origen(String pais_origen) {
        this.pais_origen = pais_origen;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setLema(String lema) {
        this.lema = lema;
    }

    public void setSuscripcion(Integer suscripcion) {
        this.suscripcion = suscripcion;
    }

    public void setColores(String colores) {
        this.colores = colores;
    }
}


        